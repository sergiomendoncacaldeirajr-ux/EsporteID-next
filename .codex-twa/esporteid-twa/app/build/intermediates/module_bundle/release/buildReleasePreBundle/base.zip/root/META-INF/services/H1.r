D1.a
